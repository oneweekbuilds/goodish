import { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { LandingPage } from './components/LandingPage';
import { DashboardPage } from './components/DashboardPage';
import { InsightDetailPage } from './components/InsightDetailPage';
import { AboutPage } from './components/AboutPage';
import { SignInPage } from './components/SignInPage';
import { ErrorPage } from './components/ErrorPage';
import { PricingPage } from './components/PricingPage';
import { PrivacyTermsPage } from './components/PrivacyTermsPage';
import { DashboardTierDemo } from './components/DashboardTierDemo';
import { Toaster } from './components/ui/sonner';

type Page = 'landing' | 'dashboard' | 'insight' | 'about' | 'signin' | 'error' | 'pricing' | 'legal' | 'tier-demo';
type Plan = 'free' | 'premium';

interface NavigationParams {
  topic?: string;
}

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('landing');
  const [navigationParams, setNavigationParams] = useState<NavigationParams>({});
  const [currentPlan, setCurrentPlan] = useState<Plan>(() => {
    const saved = localStorage.getItem('algorithmlens_plan');
    // Migrate old plan values to new two-tier system
    if (saved === 'pro' || saved === 'plus') {
      return 'premium';
    }
    return (saved as Plan) || 'free';
  });

  // Scroll to top on page change
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentPage]);

  // Persist plan to localStorage
  useEffect(() => {
    localStorage.setItem('algorithmlens_plan', currentPlan);
  }, [currentPlan]);

  const handlePlanChange = (plan: Plan) => {
    setCurrentPlan(plan);
  };

  const handleNavigate = (page: string, params?: NavigationParams) => {
    setCurrentPage(page as Page);
    if (params) {
      setNavigationParams(params);
    } else {
      setNavigationParams({});
    }
  };

  // Don't show navbar/footer on sign in page or tier demo
  const showNavbarFooter = currentPage !== 'signin' && currentPage !== 'error' && currentPage !== 'tier-demo';

  return (
    <div className="min-h-screen bg-background text-foreground font-sans antialiased">
      {showNavbarFooter && (
        <Navbar 
          onNavigate={handleNavigate} 
          currentPage={currentPage}
          currentPlan={currentPlan}
          onPlanChange={handlePlanChange}
        />
      )}

      <main>
        {currentPage === 'landing' && <LandingPage onNavigate={handleNavigate} />}
        {currentPage === 'dashboard' && (
          <DashboardPage 
            onNavigate={handleNavigate}
            currentPlan={currentPlan}
            onUpgrade={() => handleNavigate('pricing')}
          />
        )}
        {currentPage === 'insight' && (
          <InsightDetailPage
            onNavigate={handleNavigate}
            topic={navigationParams.topic}
          />
        )}
        {currentPage === 'about' && <AboutPage onNavigate={handleNavigate} />}
        {currentPage === 'signin' && <SignInPage onNavigate={handleNavigate} />}
        {currentPage === 'error' && <ErrorPage onNavigate={handleNavigate} />}
        {currentPage === 'pricing' && (
          <PricingPage
            currentPlan={currentPlan}
            onPlanChange={handlePlanChange}
          />
        )}
        {currentPage === 'legal' && <PrivacyTermsPage onNavigate={handleNavigate} />}
        {currentPage === 'tier-demo' && <DashboardTierDemo />}
      </main>

      {showNavbarFooter && <Footer onNavigate={handleNavigate} />}

      <Toaster />
    </div>
  );
}
