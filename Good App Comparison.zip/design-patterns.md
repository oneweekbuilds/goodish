# Design Patterns Reference — Extracted from Best-in-Class iOS Apps

This document catalogs the specific visual patterns observed in Spotify, Apple Podcasts, and the App Store that should be applied to AlgorithmLens mobile. Every measurement is real, extracted from the actual apps.

---

## Table of Contents
1. [Screen Structure](#screen-structure)
2. [Navigation and Tab Bars](#navigation-and-tab-bars)
3. [Section Headers](#section-headers)
4. [Card Variants](#card-variants)
5. [Horizontal Carousels](#horizontal-carousels)
6. [List Items](#list-items)
7. [Filter Chips / Pill Tabs](#filter-chips)
8. [Hero Cards](#hero-cards)
9. [Mini Player / Status Bars](#mini-player)
10. [Typography Scale](#typography-scale)
11. [Color Application](#color-application)
12. [Spacing System](#spacing-system)
13. [Shadows and Elevation](#shadows-and-elevation)
14. [Animations and Transitions](#animations-and-transitions)
15. [Empty and Loading States](#empty-and-loading-states)
16. [Dark Mode Specifics](#dark-mode-specifics)

---

## 1. Screen Structure {#screen-structure}

All three apps follow this vertical structure:

```
┌─────────────────────────────┐
│  Status Bar (system)        │
├─────────────────────────────┤
│  Screen Header              │  ← Large title, 28-34pt bold
│  (optional: filter chips)   │  ← Horizontal scrollable
├─────────────────────────────┤
│                             │
│  Scrollable Content Area    │  ← ScrollView or FlatList
│                             │
│  Section 1                  │
│    Section Header           │
│    Content (cards/list)     │
│                             │
│  Section 2                  │
│    Section Header           │
│    Content (cards/list)     │
│                             │
│  ... more sections ...      │
│                             │
├─────────────────────────────┤
│  Mini Player / Status       │  ← Persistent, 64px tall
├─────────────────────────────┤
│  Tab Bar                    │  ← 49pt + safe area
└─────────────────────────────┘
```

**Key observation:** The header area (title + optional filters) is NOT inside the ScrollView in Spotify — it's sticky. In Podcasts and App Store, the large title collapses on scroll (iOS native large title behavior). AlgorithmLens should use the collapsing large title pattern for a native feel.

---

## 2. Navigation and Tab Bars {#navigation-and-tab-bars}

### Bottom Tab Bar

**Spotify:**
- 5 tabs: Home, Search, Your Library, Premium, Create
- Active: brand green icon (filled) + white label
- Inactive: gray icon (outline) + gray label
- Background: solid #121212 with subtle top border

**Podcasts:**
- 4 tabs: Home, Browse, Library, Search
- Active: purple filled icon + purple label
- Inactive: gray icon + gray label
- Background: system blur (translucent)

**App Store:**
- 5 tabs: Today, Games, Apps, Arcade, Search
- Active: blue filled icon + blue label
- Inactive: gray icon + gray label
- Background: system blur (translucent)

### For AlgorithmLens:
- Active tab: PRIMARY_BLUE (#2563EB) filled icon + blue label
- Inactive tab: #94A3B8 icon + label
- Background: solid elevated surface (#1E293B dark, #FFFFFF light) with top hairline border
- Use blur effect on iOS if possible (expo-blur)
- Tab icons should be the FILLED variant when active, OUTLINE when inactive

---

## 3. Section Headers {#section-headers}

### Pattern A: Simple Header (most common)
```
Title (20-24pt, semibold, primary text color)
└── Optional: "Show all >" right-aligned, 14pt, brand color
```

### Pattern B: Header with Subtitle
```
Title (20-24pt, semibold)
Subtitle (13-14pt, secondary text color)
└── Optional: "Show all >" 
```

### Pattern C: Header with Icon
```
[Icon] Title (20-22pt, semibold)
Subtitle (13pt, secondary)
```
Used in Spotify's "For fans of Caamp" pattern with artist avatar.

### For AlgorithmLens:
- Dashboard tab names: Pattern A
- "Your Recent Scans": Pattern B with "3 scans this week" subtitle
- Insight sections: Pattern B with dimension name as title, brief description as subtitle

---

## 4. Card Variants {#card-variants}

### Small Square Card (Spotify Recents)
```
Width:  ~(screenWidth - 48) / 2  (two per row with gaps)
Height: 56-64px
Layout: [Image 48x48] [Title + Subtitle]
Radius: 8px
Background: elevated surface
```

### Medium Card (Spotify playlists, Podcasts recommendations)
```
Width:  150-180px
Height: Image (150-180px square) + Text area (~60px)
Layout: Vertical — image on top, title + subtitle below
Radius: 8-12px on image, none on text area (or full card radius)
```

### Wide Card (Spotify "Your top mixes")
```
Width:  260-300px
Height: Image (160px) + Text (~50px)
Radius: 12px
```

### Hero Card (App Store Today)
```
Width:  screenWidth - 40px (20px margin each side)
Height: 380-420px
Layout: Full-bleed image with gradient overlay at bottom
        Category label (12pt uppercase, brand color) at top-left over image
        Title (22-26pt, bold, white) at bottom-left over gradient
        Subtitle (14pt, white/80%) below title
        App info bar at very bottom (icon + name + action button)
Radius: 16-20px
Shadow: large (0 8 24 rgba(0,0,0,0.15))
```

### For AlgorithmLens — Insight Cards:
```
Width:  screenWidth - 32px
Layout: 
  Eyebrow (12pt uppercase, SECONDARY_GREEN or PRIMARY_BLUE, letterspaced)
  Title (18pt, semibold, primary text)
  Takeaway (14pt, regular, secondary text, 2-3 lines max)
  Chart/Visualization area (flexible height)
  "How we measure" expandable (14pt, tertiary text)
Radius: 16px
Background: elevated surface
Padding: 20px internal
```

---

## 5. Horizontal Carousels {#horizontal-carousels}

All three apps use the same pattern:
- `FlatList` with `horizontal`, `showsHorizontalScrollIndicator={false}`
- `snapToInterval` or `pagingEnabled` for snap behavior
- First item has left margin matching screen padding (16-20px)
- Last item has right margin matching screen padding
- Gap between items: 12-16px
- **Critical:** The rightmost visible card is partially cut off (~20% hidden) to indicate scrollability

### For AlgorithmLens:
Use horizontal carousels for:
- Recent scans (small cards with platform icon + date + brief result)
- "Related insights" within a dimension view
- Onboarding feature highlights

---

## 6. List Items {#list-items}

### App Store List Item (Games list)
```
Height:  ~72px
Layout:  [Rounded Image 48x48, radius 12px] [gap 12px] [Title + Subtitle stack] [Right action]
Title:   16pt semibold
Subtitle: 13pt regular, secondary color
Action:  Pill button ("Get") or price
Divider: hairline, indented to align with text (not full-width)
```

### Spotify Library List Item
```
Height: ~64px
Layout: [Square Image 48x48, radius 4-8px] [gap 12px] [Title + Metadata]
Title:  15-16pt medium
Meta:   13pt regular, secondary, with dot separator
```

### For AlgorithmLens — Scan History Items:
```
Height: 72px
Layout: [Platform Icon 44x44, radius 10px, tinted bg] [gap 12px] [Platform + Date stack] [Score badge]
Platform: 16pt semibold (e.g., "Instagram Feed")
Date:     13pt secondary ("2 hours ago")
Badge:    Pill with score or summary, using brand colors
Divider:  Hairline, indented past icon
```

---

## 7. Filter Chips / Pill Tabs {#filter-chips}

### Spotify Pattern:
- Horizontal scrollable row of pills
- Active pill: solid white background, dark text
- Inactive pill: transparent with white border, white text
- Pill padding: 8px vertical, 16px horizontal
- Pill radius: full (height/2)
- Gap: 8px between pills

### For AlgorithmLens:
- Active pill: PRIMARY_BLUE solid background, white text
- Inactive pill: transparent with #334155 border (dark) or #E2E8F0 border (light), primary text
- Use for: dashboard dimension tabs (Overview, Sources, Ads, Politics, Tone, Suggested)
- Scrollable if more than 4 visible at once

---

## 8. Hero Cards {#hero-cards}

### App Store Hero Pattern (for AlgorithmLens onboarding or featured content):
```
Background: Full-width image or gradient
Gradient overlay: linear-gradient from transparent (top) to rgba(0,0,0,0.7) (bottom)
Text sits on the gradient at the bottom
Category pill or eyebrow text at top-left
Large title (24-28pt bold) at bottom
Subtitle (14-15pt) below title
```

### For AlgorithmLens:
Use hero cards for:
- Dashboard welcome/status card at top ("Your Feed Analysis" with last scan summary)
- Feature promotion cards in onboarding
- Background: gradient using brand blue (#1D4ED8 → #2563EB) instead of images

---

## 9. Mini Player / Status Bar {#mini-player}

### Spotify Mini Player:
```
Height:    64px
Position:  Fixed above tab bar
Layout:    [Album art 40x40] [Title + Artist] [Controls right-aligned]
Background: Elevated surface with subtle top border
Radius:    0 (full-width) or 12px with side margins
Interaction: Tap to expand, swipe up for full player
```

### For AlgorithmLens — Scan Status Bar:
```
Height:    56px
Position:  Above tab bar (only visible when relevant)
Layout:    [Platform icon 32x32] ["Last scan: Instagram • 2h ago" or "Scanning..."] [Arrow/chevron]
Background: PRIMARY_BLUE_BG_DARK (dark mode) or PRIMARY_BLUE_BG (light mode)
Interaction: Tap to navigate to results
Active scan: Show animated progress indicator using brand green
```

---

## 10. Typography Scale {#typography-scale}

Recommended scale for AlgorithmLens (based on the three reference apps):

```
display:   34pt  heavy/black   — Splash screens only
title1:    28pt  bold          — Screen titles ("Dashboard", "Settings")
title2:    22pt  bold          — Section titles ("Source Diversity")  
title3:    20pt  semibold      — Subsection titles
headline:  17pt  semibold      — Card titles, emphasis
body:      15pt  regular       — Primary content text
callout:   14pt  regular       — Secondary content, descriptions
subhead:   13pt  regular       — Metadata, timestamps
footnote:  12pt  regular       — Captions, legal text
caption:   11pt  regular       — Smallest text (badge labels, tab labels)
overline:  11pt  medium, uppercase, letterspacing 1.5px — Eyebrow/category labels
```

**Weight mapping:** Use system fonts (San Francisco on iOS, Roboto on Android). The weights that matter: Regular (400), Medium (500), SemiBold (600), Bold (700).

---

## 11. Color Application {#color-application}

### How each color is used:

| Element | Light Mode | Dark Mode |
|---------|-----------|-----------|
| Screen background | #F8FAFC | #0F172A |
| Card/surface background | #FFFFFF | #1E293B |
| Elevated card | #FFFFFF (shadow) | #334155 |
| Primary text | #1E293B | #F1F5F9 |
| Secondary text | #64748B | #94A3B8 |
| Tertiary text | #94A3B8 | #64748B |
| Dividers/borders | #E2E8F0 | #334155 |
| Active/CTA | #2563EB (brand blue) | #2563EB |
| Success/positive | #10B981 (brand green) | #10B981 |
| Error/negative | #EF4444 | #F87171 |
| Warning | #F59E0B | #FBBF24 |
| Disabled | #CBD5E1 | #475569 |

**Never use:**
- Pure black (#000000) for text
- Pure white (#FFFFFF) for text on dark
- Any shade of purple, orange, or pink as accent colors
- Brand blue for error states
- Brand green for negative metrics

---

## 12. Spacing System {#spacing-system}

Use a 4px base grid with these named tokens:

```
xs:   4px   — Tight gaps (icon to label in tab bar)
sm:   8px   — Between related inline elements
md:   12px  — Between items in a list, pill gap
lg:   16px  — Screen horizontal padding, card internal padding
xl:   20px  — Card padding for featured cards
2xl:  24px  — Between card title and card content
3xl:  32px  — Between distinct sections
4xl:  40px  — Between major page sections
5xl:  48px  — Top of screen to first content (after header)
```

---

## 13. Shadows and Elevation {#shadows-and-elevation}

### Light Mode:
```
shadow-sm:  { shadowOffset: {width:0, height:1}, shadowOpacity:0.05, shadowRadius:2, elevation:1 }
shadow-md:  { shadowOffset: {width:0, height:2}, shadowOpacity:0.08, shadowRadius:8, elevation:3 }
shadow-lg:  { shadowOffset: {width:0, height:4}, shadowOpacity:0.12, shadowRadius:16, elevation:6 }
shadow-xl:  { shadowOffset: {width:0, height:8}, shadowOpacity:0.15, shadowRadius:24, elevation:8 }
```

### Dark Mode:
Shadows are barely visible on dark backgrounds. Instead, use **surface color differentiation**:
- Base: #0F172A
- Surface 1 (cards): #1E293B
- Surface 2 (elevated cards, modals): #334155
- Surface 3 (tooltips, dropdowns): #475569
- Optional: 1px top border in rgba(255,255,255,0.06) for extra definition

---

## 14. Animations and Transitions {#animations-and-transitions}

### Press feedback (all interactive elements):
```javascript
// Using Animated API or Reanimated
onPressIn:  scale to 0.97, duration 100ms
onPressOut: scale to 1.0, duration 150ms, spring
```

### List item stagger entrance:
```javascript
// Each item fades in with slight upward translate
opacity: 0 → 1, translateY: 8 → 0
duration: 300ms per item
stagger: 50ms delay between items
easing: ease-out
```

### Tab switching:
```javascript
// Animated indicator bar slides between tabs
translateX animated to new tab position
duration: 250ms
easing: ease-in-out
// Content crossfades
outgoing: opacity 1 → 0, duration 150ms
incoming: opacity 0 → 1, duration 200ms (starts after 100ms)
```

### Skeleton shimmer:
```javascript
// Gradient that slides left-to-right repeatedly
background: linear-gradient(90deg, surface, surface+10%, surface)
animation: translateX from -100% to 100%, duration 1500ms, loop
```

### Pull-to-refresh:
Use the platform native pull-to-refresh. Don't custom-build this.

### Screen transitions:
Use React Navigation's default native transitions. Don't override with custom animations unless there's a specific reason.

---

## 15. Empty and Loading States {#empty-and-loading-states}

### Loading:
- Use skeleton screens that mirror the shape of the content they'll replace
- Skeletons use rounded rectangles matching card/text shapes
- Shimmer animation (see above)
- Never use spinner-only screens

### Empty State:
```
Layout (centered vertically in available space):
  [Illustration or large icon, 80-120px, muted brand color]
  Title (18pt semibold): "No scans yet"
  Description (14pt regular, secondary): "Scan your first feed to see insights"
  CTA Button (brand blue, full-width or auto-width pill): "Start Scanning"
```

### Error State:
Same layout as empty but with error icon and retry button.

---

## 16. Dark Mode Specifics {#dark-mode-specifics}

### What changes in dark mode:
- Background → deep slate (#0F172A)
- Cards → elevated surface (#1E293B)
- Text → inverted (primary becomes #F1F5F9, secondary becomes #94A3B8)
- Shadows → replaced with surface color differentiation + optional subtle borders
- Brand colors → stay the same (blue and green both work on dark)
- Charts → ensure labels/gridlines use dark-appropriate colors
- Images → no change needed, rounded corners stay
- Gradients → shift to darker base (e.g., #0F172A → #1E293B instead of white → gray)

### What does NOT change:
- Border radius values
- Spacing values
- Typography sizes and weights
- Icon sizes
- Touch target sizes
- Layout structure
- Animation timing
