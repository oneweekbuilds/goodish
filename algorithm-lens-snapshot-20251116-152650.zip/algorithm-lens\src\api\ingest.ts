/**
 * Ingest API client
 * Typed client for the AlgorithmLens ingest API
 */

import { getConnectedSettings } from "../lib/connectedSettings";

export type SessionRow = {
  sessionId: string;
  startedAt: number;        // epoch ms
  finishedAt: number | null;
  deviceId: string;
  events: number;
};

export type EventRow = {
  id: string;
  sessionId: string;
  accountId: string;
  ts: number;               // epoch ms
  type: string;
  payload: unknown;
};

type SessionsResponse = {
  sessions: SessionRow[];
};

type EventsResponse = {
  events: EventRow[];
  nextOffset: number | null;
};

function apiBase() {
  const { apiBaseUrl } = getConnectedSettings();
  if (!apiBaseUrl) throw new Error("API Base URL is not set.");
  return apiBaseUrl.replace(/\/$/, "");
}

/**
 * Internal fetch helper with error handling
 */
async function fetchJson<T>(path: string): Promise<T> {
  const url = `${apiBase()}${path}`;

  const response = await fetch(url, {
    headers: {
      'Accept': 'application/json',
    },
  });

  if (!response.ok) {
    const status = response.status;
    const statusText = response.statusText;
    let message = `HTTP ${status}: ${statusText}`;

    // Try to extract error message from response body
    try {
      const errorBody = await response.json();
      if (errorBody.error) {
        message = `HTTP ${status}: ${errorBody.error}`;
      }
    } catch {
      // If we can't parse the error body, use the default message
    }

    throw new Error(message);
  }

  return response.json();
}

/**
 * List sessions for an account
 */
export async function listSessions(accountId: string): Promise<SessionsResponse> {
  return fetchJson<SessionsResponse>(`/v1/sessions?accountId=${encodeURIComponent(accountId)}`);
}

/**
 * List events for a session with pagination
 */
export async function listEvents(
  accountId: string,
  sessionId: string,
  limit: number = 1000,
  offset: number = 0
): Promise<EventsResponse> {
  const params = new URLSearchParams({
    accountId,
    sessionId,
    limit: limit.toString(),
    offset: offset.toString(),
  });

  const response = await fetchJson<{
    events: Array<{ eventId: string; seenAt: number; payload: any }>;
    nextOffset: number | null;
  }>(`/v1/events?${params.toString()}`);

  // Map API response to our internal EventRow format
  const events: EventRow[] = response.events.map(e => ({
    id: e.eventId,
    sessionId: sessionId,
    accountId: accountId,
    ts: e.seenAt,
    type: e.payload?.platformGuess || 'unknown',
    payload: e.payload,
  }));

  return {
    events,
    nextOffset: response.nextOffset,
  };
}
